import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";

import "./index.css";
import App from "./App";

import AIProvider from "./features/ai/context/AIProvider";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <AIProvider>
        <Toaster position="top-right" />

        <App />
      </AIProvider>
    </BrowserRouter>
  </React.StrictMode>
);