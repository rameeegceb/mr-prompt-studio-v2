export interface ImprovementResult {

    originalPrompt: string;

    improvedPrompt: string;

    score: number;

    framework: string;

    confidence: number;

    improvements: string[];

    recommendations: string[];

    techniques: string[];

    explanation: string;

}