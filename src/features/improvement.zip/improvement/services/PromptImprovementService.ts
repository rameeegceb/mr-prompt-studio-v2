import { ImprovementResult } from "../models/ImprovementResult";

class PromptImprovementService {

    async improve(prompt: string): Promise<ImprovementResult> {

        await new Promise(resolve => setTimeout(resolve, 1000));

        return {

            originalPrompt: prompt,

            improvedPrompt:
`Act as a Senior Business Analyst.

Context:
${prompt}

Generate a complete response.

Requirements:

- Clear structure
- Professional tone
- Step-by-step
- Output in Markdown
- Include assumptions
- Include recommendations`,

            score: 91,

            framework: "PROMPT Framework",

            confidence: 96,

            improvements: [

                "Added Role",

                "Added Context",

                "Defined Output Format",

                "Improved Constraints",

                "Improved Instructions"

            ],

            recommendations: [

                "Provide examples",

                "Specify audience",

                "Add business context"

            ],

            techniques: [

                "Role Prompting",

                "Structured Prompting",

                "Constraint Prompting"

            ],

            explanation:
                "Prompt improved using enterprise prompt engineering best practices."

        };

    }

}

export default new PromptImprovementService();