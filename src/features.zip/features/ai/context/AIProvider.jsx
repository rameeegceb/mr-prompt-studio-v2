import { useEffect, useState } from "react";
import AIContext from "./AIContext";
import defaultConfig from "../config/defaultConfig";
import StorageService from "../services/StorageService";

export default function AIProvider({ children }) {
    const [config, setConfig] = useState(defaultConfig);

    useEffect(() => {
        const saved = StorageService.loadSettings();

        if (saved) {
            setConfig(saved);
        }
    }, []);

    const updateConfig = (updates) => {
        const newConfig = {
            ...config,
            ...updates
        };

        setConfig(newConfig);

        StorageService.saveSettings(newConfig);
    };

    return (
        <AIContext.Provider
            value={{
                config,
                updateConfig
            }}
        >
            {children}
        </AIContext.Provider>
    );
}